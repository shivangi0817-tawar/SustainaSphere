import React from 'react';

const SustainabilityScore = ({ scoreData }) => {
  if (!scoreData) return null; // safe check

  return (
    <div className="alert alert-info my-4">
      <h5>🌿 Sustainability Score Breakdown:</h5>
      <ul className="list-unstyled mb-0">
        {Object.entries(scoreData).map(([key, val]) => (
          <li key={key}>
            <strong>{key}</strong>: {val} pts
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SustainabilityScore;
